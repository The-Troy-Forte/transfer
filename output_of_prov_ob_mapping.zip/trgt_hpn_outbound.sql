-- =============================================================================
-- Model   : trgt_hpn_outbound
-- Purpose : Outbound file creation control for Health Plan Network (HPN) target
-- Env     : Development
-- Pattern : trgt_hpn*
-- =============================================================================

{{
  config(
    materialized  = 'table',
    schema        = 'outbound',
    alias         = 'trgt_hpn_outbound',
    tags          = ['outbound', 'hpn', 'daily', 'dev'],
    meta          = {
      'owner'       : 'data_engineering',
      'domain'      : 'health_plan_network',
      'file_target' : 'trgt_hpn*',
      'env'         : 'dev'
    }
  )
}}

-- ---------------------------------------------------------------------------
-- Ref: Source staging model
-- Swap src_hpn_members for your actual upstream model name as needed
-- ---------------------------------------------------------------------------
with source as (

    select * from {{ ref('src_hpn_members') }}

),

-- ---------------------------------------------------------------------------
-- ROW FILTER: Apply business rules before column selection
-- Controlled via dbt_project.yml vars (see outbound_file_config.yml)
-- ---------------------------------------------------------------------------
filtered as (

    select *
    from source
    where 1 = 1

        -- Active records only
        and record_status       = {{ var('hpn_filter_record_status', "'A'") }}

        -- Date range window (defaults to current month)
        and effective_date      >= {{ var('hpn_filter_effective_date_start', "date_trunc('month', current_date)") }}
        and effective_date      <= {{ var('hpn_filter_effective_date_end',   "current_date") }}

        -- Plan type filter (comma-separated string expanded below)
        and plan_type_code      in ({{ var('hpn_filter_plan_types', "'HMO','PPO','EPO'") }})

        -- Exclude test / synthetic members
        and is_test_record      = false

),

-- ---------------------------------------------------------------------------
-- COLUMN SELECTION / FIELD MAPPING
-- Rename source columns to outbound target names here
-- ---------------------------------------------------------------------------
mapped as (

    select
        -- Member identifiers
        member_id                                       as MBR_ID,
        subscriber_id                                   as SUBSC_ID,
        medicaid_id                                     as MCAID_ID,

        -- Name fields
        upper(last_name)                                as MBR_LAST_NM,
        upper(first_name)                               as MBR_FIRST_NM,
        upper(middle_initial)                           as MBR_MID_INIT,

        -- Demographics
        date_of_birth                                   as MBR_DOB,
        gender_code                                     as MBR_GNDR_CD,

        -- Plan / Network
        plan_id                                         as PLAN_ID,
        plan_type_code                                  as PLAN_TYPE_CD,
        network_id                                      as NTW_ID,
        network_name                                    as NTW_NM,

        -- Eligibility window
        effective_date                                  as EFF_DT,
        termination_date                                as TERM_DT,

        -- Address
        upper(address_line1)                            as ADDR_LN1,
        upper(address_line2)                            as ADDR_LN2,
        upper(city)                                     as CITY_NM,
        state_code                                      as STATE_CD,
        zip_code                                        as ZIP_CD,

        -- Audit / control fields
        record_status                                   as REC_STAT_CD,
        current_timestamp                               as FILE_EXTRACT_DT,
        {{ var('hpn_batch_id', 'null') }}               as BATCH_ID

    from filtered

)

select * from mapped
