# trgt_hpn* — DBT Outbound File Control
**Environment:** Development | **Domain:** Health Plan Network (HPN)

---

## File Inventory

| File | Purpose |
|------|---------|
| `dbt_project.yml` | Master control — all vars for schedule, format, path, naming, filters |
| `models/trgt_hpn_outbound.sql` | Core model — row filtering + column mapping |
| `models/schema.yml` | Column docs, data tests, model metadata |
| `macros/generate_hpn_outbound_file.sql` | Post-run macro — serializes model to file |

---

## Quick-Start

```bash
# 1. Run the model
dbt run --select trgt_hpn_outbound

# 2. Run data tests
dbt test --select trgt_hpn_outbound

# 3. Export the file (uses all vars from dbt_project.yml)
dbt run-operation generate_hpn_outbound_file

# 4. Export for a specific plan
dbt run-operation generate_hpn_outbound_file --args '{"plan_id": "HMO001"}'
```

---

## Control Reference

### Schedule
| Var | Default | Description |
|-----|---------|-------------|
| `hpn_run_frequency` | `daily` | `daily \| weekly \| monthly \| on-demand` |
| `hpn_run_time_utc` | `03:00` | Preferred extract window (UTC) |
| `hpn_run_day_of_week` | `MON-FRI` | Days to run; `*` = every day |
| `hpn_run_day_of_month` | `*` | `*` = every day; `1` = 1st of month |

### Row Filters
| Var | Default | Description |
|-----|---------|-------------|
| `hpn_filter_record_status` | `'A'` | `'A'`=Active, `'T'`=Termed, `'*'`=All |
| `hpn_filter_effective_date_start` | Start of current month | Lower bound of eligibility window |
| `hpn_filter_effective_date_end` | `current_date` | Upper bound of eligibility window |
| `hpn_filter_plan_types` | `'HMO','PPO','EPO'` | Quoted comma-separated plan type codes |

### File Format
| Var | Default | Description |
|-----|---------|-------------|
| `hpn_file_format` | `pipe` | `pipe \| csv \| fixed_width` |
| `hpn_delimiter` | `\|` | Field delimiter character |
| `hpn_file_header` | `true` | Include header row |
| `hpn_file_encoding` | `UTF-8` | Character encoding |
| `hpn_file_compression` | `none` | `none \| gzip \| zip` |
| `hpn_file_quote_all` | `false` | Wrap all fields in quotes (CSV only) |

### Output Path
| Var | Default | Description |
|-----|---------|-------------|
| `hpn_output_base_path` | `/data/outbound/dev/hpn` | Root output directory |
| `hpn_output_subfolder` | `YYYY/MM/DD` | Date-based subfolder (auto-generated) |

Resolved path: `/data/outbound/dev/hpn/2025/06/15/`

### File Naming
Pattern: `{prefix}_{plan_id}_{date_stamp}_{sequence}{suffix}.{ext}`
Example: `trgt_hpn_ALL_20250615_001.txt`

| Var | Default | Description |
|-----|---------|-------------|
| `hpn_filename_prefix` | `trgt_hpn` | File name prefix |
| `hpn_filename_plan_id` | `ALL` | Plan token; override per-plan run |
| `hpn_filename_date_format` | `%Y%m%d` | strftime date pattern |
| `hpn_filename_sequence` | `001` | Run sequence / version |
| `hpn_filename_ext` | `txt` | File extension |
| `hpn_filename_suffix` | _(empty)_ | Optional suffix before extension |

---

## Runtime Overrides

Override any var at runtime without editing YAML:

```bash
dbt run --select trgt_hpn_outbound \
  --vars '{
    "hpn_filter_plan_types": "'\''HMO'\''",
    "hpn_filter_effective_date_start": "'\''2025-01-01'\''",
    "hpn_filename_plan_id": "HMO001",
    "hpn_filename_sequence": "002",
    "hpn_file_format": "csv",
    "hpn_delimiter": ","
  }'
```

---

## Promoting to Staging / Production

1. Change `hpn_output_base_path` to the environment path:
   - Staging: `/data/outbound/stg/hpn`
   - Production: `/data/outbound/prod/hpn`
2. Update the `dbt_project.yml` `meta.env` tag.
3. Update the dbt `profile` target.
4. Remove `+tags: ['dev']` or replace with `['stg']` / `['prod']`.
