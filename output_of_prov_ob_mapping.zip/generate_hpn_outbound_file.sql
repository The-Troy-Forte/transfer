-- =============================================================================
-- Macro : generate_hpn_outbound_file
-- Purpose: Serializes trgt_hpn_outbound model to a delimited or fixed-width
--          file. Called post-model-run by the orchestrator or an on-run-end hook.
--
-- Usage (in dbt on-run-end or operations):
--   dbt run-operation generate_hpn_outbound_file
--   dbt run-operation generate_hpn_outbound_file --args '{plan_id: "HMO001"}'
-- =============================================================================

{% macro generate_hpn_outbound_file(plan_id=none) %}

    {# ── Resolve runtime variables ── #}
    {% set file_format    = var('hpn_file_format',           'pipe')        %}
    {% set delimiter      = var('hpn_delimiter',             '|')           %}
    {% set has_header     = var('hpn_file_header',           true)          %}
    {% set encoding       = var('hpn_file_encoding',         'UTF-8')       %}
    {% set compression    = var('hpn_file_compression',      'none')        %}
    {% set quote_all      = var('hpn_file_quote_all',        false)         %}

    {% set base_path      = var('hpn_output_base_path',      '/data/outbound/dev/hpn') %}
    {% set subfolder      = var('hpn_output_subfolder',      run_started_at.strftime('%Y/%m/%d')) %}
    {% set output_path    = base_path ~ '/' ~ subfolder %}

    {% set prefix         = var('hpn_filename_prefix',       'trgt_hpn')    %}
    {% set plan_token     = plan_id if plan_id else var('hpn_filename_plan_id', 'ALL') %}
    {% set date_stamp     = run_started_at.strftime(var('hpn_filename_date_format', '%Y%m%d')) %}
    {% set sequence       = var('hpn_filename_sequence',     '001')         %}
    {% set ext            = var('hpn_filename_ext',          'txt')         %}
    {% set suffix         = var('hpn_filename_suffix',       '')            %}

    {% set filename       = prefix ~ '_' ~ plan_token ~ '_' ~ date_stamp ~ '_' ~ sequence ~ suffix ~ '.' ~ ext %}
    {% set full_path      = output_path ~ '/' ~ filename %}

    {# ── Log resolved config to dbt console ── #}
    {{ log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', info=true) }}
    {{ log('  HPN Outbound File Control — trgt_hpn*',                   info=true) }}
    {{ log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', info=true) }}
    {{ log('  Format      : ' ~ file_format ~ ' (delimiter: ' ~ delimiter ~ ')', info=true) }}
    {{ log('  Header row  : ' ~ has_header,                              info=true) }}
    {{ log('  Encoding    : ' ~ encoding,                                info=true) }}
    {{ log('  Compression : ' ~ compression,                             info=true) }}
    {{ log('  Output path : ' ~ output_path,                             info=true) }}
    {{ log('  Filename    : ' ~ filename,                                info=true) }}
    {{ log('  Full path   : ' ~ full_path,                               info=true) }}
    {{ log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', info=true) }}

    {# ── Generate COPY / UNLOAD statement (adapter-specific) ── #}
    {# Snowflake ── #}
    {% if target.type == 'snowflake' %}

        {% set copy_sql %}
            COPY INTO '{{ full_path }}'
            FROM {{ ref('trgt_hpn_outbound') }}
            FILE_FORMAT = (
                TYPE             = 'CSV'
                FIELD_DELIMITER  = '{{ delimiter }}'
                NULL_IF          = ('')
                EMPTY_FIELD_AS_NULL = TRUE
                {% if quote_all %} FIELD_OPTIONALLY_ENCLOSED_BY = '"' {% endif %}
                COMPRESSION      = {% if compression == 'gzip' %}'GZIP'{% else %}'NONE'{% endif %}
            )
            HEADER           = {{ has_header | upper }}
            OVERWRITE        = TRUE
            SINGLE           = TRUE
        {% endset %}

        {% do run_query(copy_sql) %}

    {# Redshift ── #}
    {% elif target.type == 'redshift' %}

        {% set unload_sql %}
            UNLOAD (
                'SELECT * FROM {{ target.schema }}.trgt_hpn_outbound'
            )
            TO 's3://{{ var("hpn_s3_bucket","your-bucket") }}/{{ output_path }}/{{ filename }}'
            IAM_ROLE '{{ var("hpn_iam_role","arn:aws:iam::ACCOUNT:role/RedshiftS3Role") }}'
            DELIMITER '{{ delimiter }}'
            {% if has_header %} HEADER {% endif %}
            {% if compression == 'gzip' %} GZIP {% endif %}
            ALLOWOVERWRITE
            PARALLEL OFF
        {% endset %}

        {% do run_query(unload_sql) %}

    {# BigQuery ── #}
    {% elif target.type == 'bigquery' %}

        {% set export_sql %}
            EXPORT DATA OPTIONS (
                uri         = 'gs://{{ var("hpn_gcs_bucket","your-bucket") }}/{{ full_path }}',
                format      = 'CSV',
                overwrite   = true,
                header      = {{ has_header | lower }},
                field_delimiter = '{{ delimiter }}'
            ) AS
            SELECT * FROM `{{ target.project }}.{{ target.schema }}.trgt_hpn_outbound`
        {% endset %}

        {% do run_query(export_sql) %}

    {# Postgres / generic fallback ── #}
    {% else %}

        {% set copy_sql %}
            COPY {{ ref('trgt_hpn_outbound') }}
            TO '{{ full_path }}'
            DELIMITER '{{ delimiter }}'
            {% if has_header %} HEADER {% endif %}
            CSV
            ENCODING '{{ encoding }}'
        {% endset %}

        {% do run_query(copy_sql) %}

    {% endif %}

    {{ log('  ✓ File written successfully: ' ~ full_path, info=true) }}

{% endmacro %}


-- =============================================================================
-- Macro : build_hpn_filename
-- Purpose: Utility — returns the resolved filename string for use in other
--          macros or post-hooks without executing the export.
-- =============================================================================
{% macro build_hpn_filename(plan_id=none) %}
    {%- set prefix     = var('hpn_filename_prefix',    'trgt_hpn') -%}
    {%- set plan_token = plan_id if plan_id else var('hpn_filename_plan_id', 'ALL') -%}
    {%- set date_stamp = run_started_at.strftime(var('hpn_filename_date_format', '%Y%m%d')) -%}
    {%- set sequence   = var('hpn_filename_sequence',  '001') -%}
    {%- set ext        = var('hpn_filename_ext',       'txt') -%}
    {%- set suffix     = var('hpn_filename_suffix',    '') -%}
    {{- prefix ~ '_' ~ plan_token ~ '_' ~ date_stamp ~ '_' ~ sequence ~ suffix ~ '.' ~ ext -}}
{% endmacro %}
