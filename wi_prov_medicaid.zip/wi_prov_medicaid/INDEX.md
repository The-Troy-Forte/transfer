# Wisconsin Provider Medicaid - dbt Project Files

## 🎯 **CONFIGURED FOR WINDOWS + DUCKDB**

This project is specifically configured to run on **Windows** using **DuckDB** as the database.

## 📁 Project Structure

```
wi_prov_medicaid/
├── README.md                          # Main project documentation
├── MIGRATION_GUIDE.md                 # Informatica to dbt migration guide
├── dbt_project.yml                    # dbt project configuration
├── packages.yml                       # dbt package dependencies
├── profiles.yml.template              # Database connection template
├── .env.example                       # Environment variables template
├── Makefile                           # Build automation and shortcuts
├── workflow_pipeline.yml              # Complete workflow orchestration
├── schema_documentation.yml           # Comprehensive schema documentation
├── ADDITIONAL_MODELS_REFERENCE.sql    # Reference SQL for all type models
│
└── models/
    ├── sources.yml                    # Source table definitions
    │
    ├── staging/
    │   ├── stg_wi_ma_inbound_raw.sql          # Stage 1: Load raw file
    │   └── by_type/
    │       ├── stg_provider_file_information.sql    # Type 00
    │       ├── stg_provider.sql                     # Type 01
    │       ├── stg_provider_address.sql             # Type 02
    │       └── [Types 03-14 - See ADDITIONAL_MODELS_REFERENCE.sql]
    │
    ├── intermediate/
    │   └── int_wi_ma_parsed_records.sql       # Stage 2: Parse and route
    │
    └── outbound/
        ├── out_wi_ma_provider.sql             # Outbound provider
        ├── out_wi_ma_facility.sql             # Outbound facility
        └── out_wi_ma_control.sql              # Control file
```

## 🚀 Quick Start (Windows)

### Option 1: Automated Setup (Recommended)
```cmd
REM 1. Run setup script
setup_windows.bat

REM 2. Generate sample data (optional)
python generate_sample_data.py

REM 3. Run the pipeline
.\run.ps1 run
```

### Option 2: Manual Setup
```powershell
# 1. Install dbt with DuckDB
pip install dbt-core dbt-duckdb

# 2. Create directories
mkdir C:\data\duckdb
mkdir C:\data\wi_medicaid

# 3. Copy profile configuration
copy profiles_duckdb_windows.yml %USERPROFILE%\.dbt\profiles.yml

# 4. Test connection
dbt debug

# 5. Run pipeline
dbt run
```

### 1. Setup (5 minutes)
```bash
# Copy the profile template
cp profiles.yml.template ~/.dbt/profiles.yml

# Edit with your database credentials
nano ~/.dbt/profiles.yml

# Set environment variable
export DBT_PASSWORD='your_password'

# Test connection
make debug
```

### 2. Install Dependencies (2 minutes)
```bash
# Install dbt packages
make deps

# Or manually:
dbt deps
```

### 3. Run the Pipeline (10 minutes)
```bash
# Run complete pipeline
make run

# Or run in stages:
make run-inbound    # Load and parse inbound file
make run-outbound   # Create outbound extracts

# Or use dbt directly:
dbt run --select tag:inbound
dbt run --select tag:outbound
```

### 4. Test (5 minutes)
```bash
# Run all tests
make test

# Or:
dbt test
```

### 5. View Documentation (2 minutes)
```bash
# Generate and serve docs
make docs

# Opens in browser at http://localhost:8080
```

## 📋 File Descriptions

### Core Configuration Files

| File | Purpose | When to Edit |
|------|---------|--------------|
| `dbt_project.yml` | Main project config | Change project settings, add tags, adjust schemas |
| `packages.yml` | dbt package dependencies | Add new dbt packages |
| `profiles_duckdb_windows.yml` | DuckDB connection template for Windows | Copy to %USERPROFILE%\\.dbt\\profiles.yml |
| `.env.example` | Environment variables | Never (copy to .env first) |
| `Makefile` | Build automation (Linux/Mac) | Add custom commands |
| `run.ps1` | PowerShell commands (Windows) | Add custom commands |
| `setup_windows.bat` | Windows setup script | Run once to set up |

### Documentation Files

| File | Purpose | Audience |
|------|---------|----------|
| `README_WINDOWS.md` | **START HERE** - Windows + DuckDB guide | Windows users |
| `README.md` | Full project documentation | All users |
| `MIGRATION_GUIDE.md` | Informatica → dbt guide | Developers migrating from Informatica |
| `schema_documentation.yml` | Complete schema reference | Data analysts, DBAs |
| `workflow_pipeline.yml` | Workflow orchestration spec | DevOps, data engineers |

### Windows-Specific Files

| File | Purpose |
|------|---------|
| `setup_windows.bat` | Automated Windows setup |
| `run.ps1` | PowerShell command runner |
| `profiles_duckdb_windows.yml` | DuckDB configuration for Windows |
| `generate_sample_data.py` | Create test data |

### Model Files

| File | Type | Description |
|------|------|-------------|
| `sources.yml` | Config | Defines all source tables |
| `stg_wi_ma_inbound_raw.sql` | Staging | Loads raw flat file |
| `int_wi_ma_parsed_records.sql` | Intermediate | Parses pipe-delimited records |
| `stg_provider*.sql` | Staging | Type-specific tables (00-14) |
| `out_wi_ma_*.sql` | Output | Final outbound tables |

## 🔄 Data Flow

```
1. INBOUND FLOW
   Flat File → stg_wi_ma_inbound_raw → int_wi_ma_parsed_records → 15 Type Tables

2. OUTBOUND FLOW
   EDS Tables → out_wi_ma_provider → Final Outputs
              → out_wi_ma_facility
              → out_wi_ma_control
```

## 🎯 Common Tasks

### Daily Operations
```bash
# Process new inbound file
make run-inbound
make test

# Create outbound extracts
make run-outbound
```

### Development
```bash
# Run specific model
make run-model MODEL=stg_provider

# Test specific model  
make test-model MODEL=stg_provider

# View compiled SQL
make show-model MODEL=stg_provider
```

### Debugging
```bash
# Show compiled SQL for a model
dbt show --select stg_provider

# Run with debug logging
dbt run --select stg_provider --debug

# Compile without running
dbt compile
```

## 📊 Record Types Reference

| Type | Description | Target Table |
|------|-------------|--------------|
| 00 | File Information | stg_provider_file_information |
| 01 | Provider | stg_provider |
| 02 | Address | stg_provider_address |
| 03 | Tax | stg_provider_tax |
| 04 | Contract | stg_provider_contract |
| 05 | Type & Specialty | stg_provider_type_and_specialty |
| 06 | County & Tribe | stg_provider_county_and_tribe |
| 07 | Taxonomy | stg_provider_taxonomy |
| 08 | ACA | stg_provider_aca |
| 09 | Value Added | stg_provider_value_added |
| 10 | Waiver Program | stg_provider_waiver_program |
| 11 | NPI | stg_provider_npi |
| 12 | Waiver Service | stg_provider_waiver_service |
| 13 | License | stg_provider_license |
| 14 | Certification | stg_provider_certification |

## 🔧 Customization Points

### Add New Record Type
1. Create model: `models/staging/by_type/stg_provider_new_type.sql`
2. Update `int_wi_ma_parsed_records.sql` if needed
3. Add to `sources.yml`
4. Add tests

### Change File Location
Edit `dbt_project.yml`:
```yaml
vars:
  source_file_path: '/new/path'
  source_file_name: 'new_file.psv'
```

### Add Custom Tests
Create in `tests/` directory:
```sql
-- tests/provider_id_consistency.sql
select *
from {{ ref('stg_provider') }}
where provider_id is null
```

## 🐛 Troubleshooting

**Error: "Compilation Error: Could not find"**
- Check that ref() and source() names match exactly
- Run `dbt compile` to see what's wrong

**Error: "Database Error"**
- Check profiles.yml credentials
- Test with `make debug`
- Verify database permissions

**Error: "No such file or directory"**
- Ensure all model files are in correct directories
- Check file names match exactly (case-sensitive)

## 📚 Additional Resources

- **Main README**: `README.md` - Complete project documentation
- **Migration Guide**: `MIGRATION_GUIDE.md` - Learn Informatica → dbt
- **Schema Docs**: `schema_documentation.yml` - Full data dictionary
- **Workflow**: `workflow_pipeline.yml` - Orchestration details
- **Reference SQL**: `ADDITIONAL_MODELS_REFERENCE.sql` - All type models

## ✅ Checklist for New Users

- [ ] Read `README.md`
- [ ] Copy `profiles.yml.template` to `~/.dbt/profiles.yml`
- [ ] Update credentials in `~/.dbt/profiles.yml`
- [ ] Set `DBT_PASSWORD` environment variable
- [ ] Run `make debug` to test connection
- [ ] Run `make deps` to install packages
- [ ] Review `MIGRATION_GUIDE.md` (if coming from Informatica)
- [ ] Run `make run` to execute pipeline
- [ ] Run `make test` to validate
- [ ] Run `make docs` to view documentation

## 🎓 Learning Path

1. **Day 1**: Setup and run the pipeline
   - Complete Quick Start above
   - Review README.md

2. **Day 2**: Understand the models
   - Read schema_documentation.yml
   - Explore generated docs
   - Review a few .sql files

3. **Day 3**: Learn customization
   - Read MIGRATION_GUIDE.md
   - Try modifying a simple model
   - Add a custom test

4. **Week 2**: Advanced topics
   - Incremental models
   - Custom macros
   - Performance tuning

## 💡 Tips

- Use `make` commands for common tasks
- Always test after changes: `make test`
- Generate docs frequently: `make docs`
- Use version control (Git) for all changes
- Review compiled SQL when debugging
- Start with small changes and test incrementally

---

**Need Help?**
- Check the Makefile for all available commands: `make help`
- Review README.md for detailed documentation
- Consult MIGRATION_GUIDE.md for Informatica equivalents
- Check dbt documentation: https://docs.getdbt.com

**Ready to Start?**
1. Run `make setup` for initial configuration
2. Run `make run` to execute the pipeline
3. Run `make docs` to explore your data

Good luck! 🚀
