-- Type 03: Provider Tax Information
-- File: models/staging/by_type/stg_provider_tax.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_03', 'tax']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as tax_id,
    trim(field_04) as tax_id_type,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '03';

-- Type 04: Provider Contract
-- File: models/staging/by_type/stg_provider_contract.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_04', 'contract']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as contract_number,
    trim(field_04) as contract_type,
    try_to_date(field_05, 'YYYY-MM-DD') as effective_date,
    try_to_date(field_06, 'YYYY-MM-DD') as end_date,
    trim(field_07) as contract_status,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '04';

-- Type 05: Provider Type and Specialty
-- File: models/staging/by_type/stg_provider_type_and_specialty.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_05', 'specialty']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as provider_type,
    trim(field_04) as specialty_code,
    trim(field_05) as specialty_description,
    trim(field_06) as primary_specialty_flag,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '05';

-- Type 06: Provider County and Tribe
-- File: models/staging/by_type/stg_provider_county_and_tribe.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_06', 'county_tribe']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as county_code,
    trim(field_04) as county_name,
    trim(field_05) as tribe_code,
    trim(field_06) as tribe_name,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '06';

-- Type 07: Provider Taxonomy
-- File: models/staging/by_type/stg_provider_taxonomy.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_07', 'taxonomy']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as taxonomy_code,
    trim(field_04) as taxonomy_description,
    trim(field_05) as primary_flag,
    trim(field_06) as taxonomy_group,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '07';

-- Type 08: Provider ACA
-- File: models/staging/by_type/stg_provider_aca.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_08', 'aca']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as aca_indicator,
    try_to_date(field_04, 'YYYY-MM-DD') as aca_effective_date,
    trim(field_05) as aca_status,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '08';

-- Type 09: Provider Value Added
-- File: models/staging/by_type/stg_provider_value_added.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_09', 'value_added']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as service_code,
    trim(field_04) as service_description,
    try_to_date(field_05, 'YYYY-MM-DD') as effective_date,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '09';

-- Type 10: Provider Waiver Program
-- File: models/staging/by_type/stg_provider_waiver_program.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_10', 'waiver']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as waiver_program_code,
    trim(field_04) as waiver_program_name,
    try_to_date(field_05, 'YYYY-MM-DD') as enrollment_date,
    trim(field_06) as program_status,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '10';

-- Type 11: Provider NPI
-- File: models/staging/by_type/stg_provider_npi.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_11', 'npi']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as npi,
    trim(field_04) as npi_type,
    try_to_date(field_05, 'YYYY-MM-DD') as npi_effective_date,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '11';

-- Type 12: Provider Waiver Service
-- File: models/staging/by_type/stg_provider_waiver_service.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_12', 'waiver_service']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as service_code,
    trim(field_04) as service_name,
    trim(field_05) as service_category,
    try_to_date(field_06, 'YYYY-MM-DD') as effective_date,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '12';

-- Type 13: Provider License
-- File: models/staging/by_type/stg_provider_license.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_13', 'license']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as license_number,
    trim(field_04) as license_type,
    try_to_date(field_05, 'YYYY-MM-DD') as issue_date,
    try_to_date(field_06, 'YYYY-MM-DD') as expiration_date,
    trim(field_07) as issuing_state,
    trim(field_08) as license_status,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '13';

-- Type 14: Provider Certification
-- File: models/staging/by_type/stg_provider_certification.sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'type_14', 'certification']
    )
}}

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as certification_number,
    trim(field_04) as certification_type,
    try_to_date(field_05, 'YYYY-MM-DD') as effective_date,
    try_to_date(field_06, 'YYYY-MM-DD') as expiration_date,
    trim(field_07) as certifying_organization,
    trim(field_08) as certification_status,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '14';
