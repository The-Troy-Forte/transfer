# Informatica to dbt Migration Guide

## Wisconsin Provider Medicaid Project

This document provides detailed guidance for migrating from Informatica PowerCenter to dbt.

---

## Overview

### What Changed

| Aspect | Informatica | dbt |
|--------|-------------|-----|
| **Language** | GUI-based mappings | SQL and YAML |
| **Version Control** | XML exports | Git-native |
| **Testing** | Manual/external | Built-in test framework |
| **Documentation** | Separate documents | Auto-generated from code |
| **Orchestration** | Workflow Manager | External tools (Airflow, etc.) |
| **Development** | Designer client | Any text editor + CLI |

---

## Transformation Mapping

### Source Qualifier → source() macro

**Informatica:**
```
Source Qualifier SQ_WI_MA_INBOUND
  Source: WI_MA_INBOUND_PROVIDER_FILE
  Filter: ENTIRE_RECORD IS NOT NULL
```

**dbt:**
```yaml
# models/sources.yml
sources:
  - name: prov_ib
    tables:
      - name: wi_ma_inbound_provider_file
```

```sql
-- models/staging/stg_wi_ma_inbound_raw.sql
select *
from {{ source('prov_ib', 'wi_ma_inbound_provider_file') }}
where entire_record is not null
```

---

### Expression Transformation → SELECT with CASE

**Informatica:**
```
Expression EXP_Parse_Fields
  O_RECORD_TYPE = SUBSTR(ENTIRE_RECORD, 1, 2)
  O_PROVIDER_ID = TRIM(SUBSTR(ENTIRE_RECORD, 4, 50))
  O_STATUS_DESC = IIF(STATUS = 'A', 'Active', 
                     IIF(STATUS = 'I', 'Inactive', 'Unknown'))
```

**dbt:**
```sql
select
    substr(entire_record, 1, 2) as record_type,
    trim(substr(entire_record, 4, 50)) as provider_id,
    case
        when status = 'A' then 'Active'
        when status = 'I' then 'Inactive'
        else 'Unknown'
    end as status_desc
from {{ ref('source_table') }}
```

---

### Router Transformation → Multiple Models with WHERE

**Informatica:**
```
Router RTR_type
  Group1 (Type_00): RECORD_TYPE = '00' → Provider_File_Information
  Group2 (Type_01): RECORD_TYPE = '01' → Provider
  Group3 (Type_02): RECORD_TYPE = '02' → Provider_Address
  ...
```

**dbt:**
```sql
-- models/staging/by_type/stg_provider_file_information.sql
select * from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '00'

-- models/staging/by_type/stg_provider.sql
select * from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '01'

-- models/staging/by_type/stg_provider_address.sql
select * from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '02'
```

---

### Aggregator Transformation → GROUP BY

**Informatica:**
```
Aggregator AGG_Count_Records
  Group By: PROVIDER_ID
  COUNT(*) AS RECORD_COUNT
  MAX(LOAD_DATE) AS LAST_LOAD
```

**dbt:**
```sql
select
    provider_id,
    count(*) as record_count,
    max(load_date) as last_load
from {{ ref('source_model') }}
group by provider_id
```

---

### Joiner Transformation → JOIN

**Informatica:**
```
Joiner JNR_Provider_Address
  Master: Provider
  Detail: Provider_Address
  Condition: Provider.PROVIDER_ID = Provider_Address.PROVIDER_ID
  Type: Master Outer
```

**dbt:**
```sql
select
    p.*,
    a.address_line_1,
    a.city,
    a.state
from {{ ref('stg_provider') }} p
left join {{ ref('stg_provider_address') }} a
    on p.provider_id = a.provider_id
```

---

### Lookup Transformation → LEFT JOIN

**Informatica:**
```
Lookup LKP_Status_Codes
  Table: REF_STATUS_CODES
  Condition: STATUS_CODE = STATUS
  Return: STATUS_DESCRIPTION
```

**dbt:**
```sql
select
    p.*,
    s.status_description
from {{ ref('provider') }} p
left join {{ ref('ref_status_codes') }} s
    on p.status = s.status_code
```

---

### Filter Transformation → WHERE clause

**Informatica:**
```
Filter FIL_Active_Only
  Condition: STATUS = 'A' AND TERMINATION_DATE IS NULL
```

**dbt:**
```sql
select *
from {{ ref('source_model') }}
where status = 'A'
    and termination_date is null
```

---

### Sorter Transformation → ORDER BY

**Informatica:**
```
Sorter SRT_By_Date
  Sort Keys: EFFECTIVE_DATE DESC, PROVIDER_ID ASC
```

**dbt:**
```sql
select *
from {{ ref('source_model') }}
order by effective_date desc, provider_id asc
```

---

### Union Transformation → UNION ALL

**Informatica:**
```
Union UN_Combine_Types
  Input Group 1: Provider_Type_05
  Input Group 2: Provider_Type_06
  Input Group 3: Provider_Type_07
```

**dbt:**
```sql
select * from {{ ref('provider_type_05') }}
union all
select * from {{ ref('provider_type_06') }}
union all
select * from {{ ref('provider_type_07') }}
```

---

## Session Properties → Config Blocks

**Informatica:**
```
Session: m_ff_prov_ib_WI_medicaid_provider_incoming
  Target Load Type: Normal
  Commit Type: Target
  Commit Interval: 10000
  Error Tables: Create
```

**dbt:**
```sql
{{
    config(
        materialized='table',
        schema='prov_ib',
        tags=['inbound', 'staging'],
        on_schema_change='append_new_columns'
    )
}}

select ...
```

---

## Workflow → Orchestration YAML

**Informatica Workflow:**
```
Workflow: wf_prov_inbound
  Task 1: Start
  Task 2: s_m_ff_prov_ib_load → On Success → Task 3
  Task 3: s_m_prov_ib_split → On Success → Task 4
  Task 4: Email on Success
```

**dbt + Airflow:**
```python
from airflow import DAG
from airflow.operators.bash import BashOperator

with DAG('wi_prov_medicaid') as dag:
    
    load_raw = BashOperator(
        task_id='load_raw',
        bash_command='dbt run --select stg_wi_ma_inbound_raw'
    )
    
    parse_split = BashOperator(
        task_id='parse_split',
        bash_command='dbt run --select int_wi_ma_parsed_records staging.by_type.*'
    )
    
    load_raw >> parse_split
```

Or use **workflow_pipeline.yml** with a workflow orchestrator.

---

## Parameter Files → Variables

**Informatica:**
```
Parameter File: prov_inbound.param
  $$SourceFilePath=/work/inform/SrcFiles/wi_medicaid
  $$FileName=WI_PROV_FILE_EXTRACT.psv
```

**dbt:**
```yaml
# dbt_project.yml
vars:
  source_file_path: '/work/inform/SrcFiles/wi_medicaid'
  source_file_name: 'WI_PROV_FILE_EXTRACT.psv'
```

```sql
-- In model
'{{ var("source_file_path") }}/{{ var("source_file_name") }}'
```

---

## Error Handling

**Informatica:**
```
Session Config:
  Stop on Errors: 0 (continue)
  Error Log Table: Create
  Error Log Type: Relational
```

**dbt:**
```sql
-- Use TRY functions for safety
select
    try_to_date(field_06, 'YYYY-MM-DD') as effective_date,
    try_to_number(field_04) as record_count
from {{ ref('source') }}
```

```yaml
# Add tests
models:
  - name: stg_provider
    columns:
      - name: provider_id
        tests:
          - not_null
          - unique
```

---

## Testing

**Informatica:**
- Manual validation queries
- Data comparison tools
- Session logs

**dbt:**
```yaml
# models/staging/by_type/schema.yml
version: 2

models:
  - name: stg_provider
    description: Core provider information
    columns:
      - name: provider_id
        description: Unique provider identifier
        tests:
          - not_null
          - unique
      - name: status
        tests:
          - accepted_values:
              values: ['A', 'I', 'T', 'S']
```

```bash
# Run tests
dbt test
dbt test --select stg_provider
```

---

## Documentation

**Informatica:**
- Separate Word/PDF documents
- Manually maintained
- Often out of date

**dbt:**
```yaml
# Embedded in YAML and SQL
models:
  - name: stg_provider
    description: |
      Core provider information from Type 01 records.
      Contains legal name, status, effective dates.
    columns:
      - name: provider_id
        description: State-assigned unique identifier
```

```bash
# Generate browsable docs
dbt docs generate
dbt docs serve
```

---

## Debugging

**Informatica:**
- Session logs
- Debugger
- Target statistics

**dbt:**
```bash
# Show compiled SQL
dbt show --select model_name

# Run with debug logging
dbt run --select model_name --debug

# Check model logic
dbt compile --select model_name
cat target/compiled/wi_prov_medicaid/models/staging/stg_provider.sql
```

---

## Performance Tuning

**Informatica:**
- Partitioning
- Buffer memory
- Commit intervals
- Pushdown optimization

**dbt:**
```sql
-- Incremental models
{{
    config(
        materialized='incremental',
        unique_key='provider_id'
    )
}}

select * from {{ ref('source') }}
{% if is_incremental() %}
where load_timestamp > (select max(load_timestamp) from {{ this }})
{% endif %}
```

```yaml
# Adjust threads
# profiles.yml
threads: 8  # Parallel execution
```

---

## Migration Checklist

### Phase 1: Assessment
- [ ] Document all Informatica workflows
- [ ] List all mappings and transformations
- [ ] Identify dependencies
- [ ] Map source and target connections
- [ ] Document business logic

### Phase 2: Setup
- [ ] Install dbt
- [ ] Create project structure
- [ ] Configure connections in profiles.yml
- [ ] Set up version control (Git)

### Phase 3: Model Creation
- [ ] Create source definitions
- [ ] Convert staging models
- [ ] Convert transformation models
- [ ] Convert output models
- [ ] Add configurations (materialization, schema, etc.)

### Phase 4: Testing
- [ ] Add schema tests
- [ ] Add data tests
- [ ] Create custom tests if needed
- [ ] Compare results with Informatica output

### Phase 5: Documentation
- [ ] Add model descriptions
- [ ] Document column definitions
- [ ] Create README
- [ ] Generate dbt docs

### Phase 6: Orchestration
- [ ] Set up workflow orchestration (Airflow, Prefect, etc.)
- [ ] Configure scheduling
- [ ] Set up error notifications
- [ ] Implement monitoring

### Phase 7: Deployment
- [ ] Deploy to dev environment
- [ ] Test end-to-end
- [ ] Deploy to production
- [ ] Run parallel for validation period
- [ ] Cutover and decommission Informatica

---

## Common Pitfalls

### 1. Not Using ref() and source()
❌ **Wrong:**
```sql
select * from prov_ib.wi_ma_inbound_provider_file
```

✅ **Right:**
```sql
select * from {{ source('prov_ib', 'wi_ma_inbound_provider_file') }}
```

### 2. Hardcoding Values
❌ **Wrong:**
```sql
where file_path = '/work/inform/SrcFiles/wi_medicaid/file.psv'
```

✅ **Right:**
```sql
where file_path = '{{ var("source_file_path") }}/{{ var("source_file_name") }}'
```

### 3. Not Handling NULLs in Conversions
❌ **Wrong:**
```sql
select to_date(field_06, 'YYYY-MM-DD') as effective_date
```

✅ **Right:**
```sql
select try_to_date(field_06, 'YYYY-MM-DD') as effective_date
```

### 4. Missing Dependencies
❌ **Wrong:**
```sql
-- No indication of dependencies
select * from prov_ib.provider
```

✅ **Right:**
```sql
-- Clear dependency
select * from {{ ref('stg_provider') }}
```

---

## Training Resources

### Official dbt Resources
- **dbt Docs**: https://docs.getdbt.com
- **dbt Learn**: https://courses.getdbt.com
- **dbt Discourse**: https://discourse.getdbt.com

### Video Tutorials
- dbt Fundamentals (YouTube)
- dbt Office Hours (Weekly)
- dbt Coalesce Conference talks

### Hands-on Practice
- dbt Cloud trial
- Local dbt development
- Sample projects on GitHub

---

## Support During Migration

### Week 1-2: Setup and Training
- Install dbt
- Complete dbt Fundamentals course
- Set up project structure
- Convert 2-3 simple mappings as proof of concept

### Week 3-4: Core Model Development
- Convert all staging models
- Convert transformation logic
- Add basic tests

### Week 5-6: Advanced Features
- Add comprehensive testing
- Implement documentation
- Set up orchestration
- Performance tuning

### Week 7-8: Validation and Deployment
- Side-by-side comparison with Informatica
- Fix discrepancies
- Deploy to production
- Run in parallel

### Week 9+: Cutover and Optimization
- Monitor production runs
- Optimize performance
- Train team
- Decommission Informatica

---

## Questions and Answers

**Q: Can dbt read flat files directly?**
A: No, dbt works with database tables. You'll need to load flat files via external tools (e.g., Python scripts, COPY commands) into staging tables first.

**Q: How do I handle slowly changing dimensions?**
A: Use dbt snapshots for Type 2 SCDs.

**Q: What about complex Informatica mapplets?**
A: Convert to reusable SQL macros in dbt.

**Q: Can I schedule dbt jobs?**
A: Use dbt Cloud scheduler or external tools like Airflow, Prefect, Dagster.

**Q: How do I monitor dbt runs?**
A: dbt Cloud has built-in monitoring, or integrate with monitoring tools via logs/metadata.

---

## Conclusion

The migration from Informatica to dbt represents a shift from GUI-based, proprietary ETL to code-based, open-source analytics engineering. While the learning curve exists, the benefits include:

- **Version control**: All transformations in Git
- **Testing**: Built-in framework ensures quality
- **Documentation**: Auto-generated and always up-to-date
- **Collaboration**: Code reviews, PRs, shared development
- **Cost**: Open source alternative to expensive licensing

With this guide and the provided code, you have a complete foundation for your Wisconsin Provider Medicaid project in dbt.
