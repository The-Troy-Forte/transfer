# Wisconsin Provider Medicaid Data Pipeline

This project contains the complete data transformation pipeline for Wisconsin Medicaid Provider data, converted from Informatica PowerCenter to dbt (Data Build Tool).

## Overview

### Purpose
Process Wisconsin Medicaid provider data through two main flows:
1. **Inbound Flow**: Load flat files from the state and parse them into structured tables
2. **Outbound Flow**: Extract data from the Enterprise Data Store (EDS) and create formatted output files

### Original Informatica Components
This dbt project replaces the following Informatica assets:
- **Project**: WI_PROV_MEDICAID
- **Inbound Taskflow**: tf_ff_prov_ib_WI_provider_inbound_medicaid
- **Outbound Taskflow**: tf_prov_eds_prov_ob_WI_MA_OUTBOUND
- **15+ Mapping Templates**: Various transformation mappings

## Architecture

### Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                        INBOUND FLOW                              │
└─────────────────────────────────────────────────────────────────┘

Flat File                      Staging                  Type Tables
┌──────────┐                ┌────────────┐           ┌──────────────┐
│          │                │            │           │ Type 00:     │
│ WI_PROV_ │  ──────────>   │ WI_MA_     │  ──────>  │ File Info    │
│ FILE_    │  Load Raw      │ INBOUND_   │  Parse &  ├──────────────┤
│ EXTRACT  │  Record        │ PROVIDER_  │  Split    │ Type 01:     │
│ .psv     │                │ FILE       │           │ Provider     │
│          │                │            │           ├──────────────┤
└──────────┘                └────────────┘           │ Type 02:     │
                                                     │ Address      │
Pipe-delimited                                       ├──────────────┤
2000 char                                           │ Type 03-14:  │
records                                             │ Other tables │
                                                     └──────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                       OUTBOUND FLOW                              │
└─────────────────────────────────────────────────────────────────┘

EDS Tables                Transform              Outbound Files
┌──────────┐           ┌────────────┐        ┌─────────────────┐
│          │           │            │        │ WI_MA_PROVIDER  │
│ Provider │  ──────>  │ Business   │  ───>  ├─────────────────┤
│ Master   │  Extract  │ Logic &    │        │ WI_MA_FACILITY  │
├──────────┤           │ Transform  │        ├─────────────────┤
│ Facility │  ──────>  │            │  ───>  │ WI_MA_CONTROL   │
│ Master   │           └────────────┘        └─────────────────┘
└──────────┘
```

## Project Structure

```
wi_prov_medicaid/
│
├── dbt_project.yml              # Main dbt project configuration
├── workflow_pipeline.yml        # Orchestration workflow definition
├── schema_documentation.yml     # Comprehensive schema documentation
│
├── models/
│   ├── sources.yml             # Source table definitions
│   │
│   ├── staging/                # Staging layer
│   │   ├── stg_wi_ma_inbound_raw.sql
│   │   └── by_type/           # Type-specific models
│   │       ├── stg_provider_file_information.sql  # Type 00
│   │       ├── stg_provider.sql                   # Type 01
│   │       ├── stg_provider_address.sql           # Type 02
│   │       ├── stg_provider_tax.sql               # Type 03
│   │       ├── stg_provider_contract.sql          # Type 04
│   │       ├── stg_provider_type_and_specialty.sql # Type 05
│   │       ├── stg_provider_county_and_tribe.sql  # Type 06
│   │       ├── stg_provider_taxonomy.sql          # Type 07
│   │       ├── stg_provider_aca.sql               # Type 08
│   │       ├── stg_provider_value_added.sql       # Type 09
│   │       ├── stg_provider_waiver_program.sql    # Type 10
│   │       ├── stg_provider_npi.sql               # Type 11
│   │       ├── stg_provider_waiver_service.sql    # Type 12
│   │       ├── stg_provider_license.sql           # Type 13
│   │       └── stg_provider_certification.sql     # Type 14
│   │
│   ├── intermediate/           # Transformation layer
│   │   └── int_wi_ma_parsed_records.sql
│   │
│   └── outbound/              # Final output layer
│       ├── out_wi_ma_provider.sql
│       ├── out_wi_ma_facility.sql
│       └── out_wi_ma_control.sql
│
└── ADDITIONAL_MODELS_REFERENCE.sql  # Reference file with all type models
```

## Record Types

The Wisconsin Medicaid provider file contains 15 different record types, identified by the first 2 characters:

| Type | Description | Example Data |
|------|-------------|--------------|
| 00 | File Information | Header metadata, record counts |
| 01 | Provider | Core provider information |
| 02 | Provider Address | Mailing, physical, billing addresses |
| 03 | Provider Tax | Tax ID information (EIN/SSN) |
| 04 | Provider Contract | Contract details |
| 05 | Provider Type & Specialty | Medical specialties |
| 06 | Provider County & Tribe | Geographic service areas |
| 07 | Provider Taxonomy | NUCC taxonomy codes |
| 08 | Provider ACA | Affordable Care Act info |
| 09 | Provider Value Added | Value-added services |
| 10 | Provider Waiver Program | Medicaid waiver programs |
| 11 | Provider NPI | National Provider Identifier |
| 12 | Provider Waiver Service | Specific waiver services |
| 13 | Provider License | Professional licenses |
| 14 | Provider Certification | Professional certifications |

## Setup Instructions

### Prerequisites
- dbt Core 1.5+ or dbt Cloud account
- Oracle or compatible database connection
- Access to source file location: `/work/inform/SrcFiles/wi_medicaid`
- Appropriate database credentials

### Installation

1. **Clone or copy this project**
   ```bash
   git clone <repository_url>
   cd wi_prov_medicaid
   ```

2. **Install dbt**
   ```bash
   pip install dbt-core dbt-oracle
   ```

3. **Configure connection**
   Create/update `~/.dbt/profiles.yml`:
   ```yaml
   wi_prov_medicaid:
     target: dev
     outputs:
       dev:
         type: oracle
         host: <database_host>
         port: 1521
         user: <username>
         password: <password>
         database: CPDB
         schema: PROV_IB
         threads: 4
   ```

4. **Test connection**
   ```bash
   dbt debug
   ```

5. **Install dependencies** (if any)
   ```bash
   dbt deps
   ```

## Usage

### Running the Inbound Flow

Load and process the flat file from Wisconsin Medicaid:

```bash
# Run all inbound models
dbt run --select tag:inbound

# Run just the raw staging
dbt run --select stg_wi_ma_inbound_raw

# Run all type-specific models
dbt run --select staging.by_type.*
```

### Running the Outbound Flow

Extract and transform data from EDS to outbound schema:

```bash
# Run all outbound models
dbt run --select tag:outbound

# Run specific outbound models
dbt run --select out_wi_ma_provider out_wi_ma_facility out_wi_ma_control
```

### Running the Complete Pipeline

```bash
# Run everything in order
dbt run

# Or run with specific order
dbt run --select tag:staging
dbt run --select tag:intermediate
dbt run --select tag:outbound
```

### Testing

```bash
# Run all tests
dbt test

# Test specific models
dbt test --select stg_provider
dbt test --select out_wi_ma_provider
```

### Documentation

```bash
# Generate documentation
dbt docs generate

# Serve documentation site
dbt docs serve
```

## Configuration

### Variables

Key variables in `dbt_project.yml`:

```yaml
vars:
  source_file_path: '/work/inform/SrcFiles/wi_medicaid'
  source_file_name: 'WI_PROV_FILE_EXTRACT.psv'
  record_types: ['00', '01', '02', ..., '14']
```

Override at runtime:
```bash
dbt run --vars '{"source_file_name": "WI_PROV_FILE_EXTRACT_20240101.psv"}'
```

### Materialization

Models are configured with appropriate materializations:
- **Staging models**: `table` (for performance)
- **Intermediate models**: `view` (for flexibility)
- **Outbound models**: `table` (for final output)

## Data Quality

### Built-in Tests

The project includes comprehensive tests:
- **Not null**: Critical fields must have values
- **Unique**: Primary keys must be unique
- **Relationships**: Foreign keys must reference valid parent records
- **Accepted values**: Status codes must be from valid list

### Custom Validation

See `workflow_pipeline.yml` for additional data quality checks:
- Record type validation
- Record count reconciliation
- NPI format validation
- Active provider checks

## Migration from Informatica

### Mapping Equivalents

| Informatica Component | dbt Equivalent | Notes |
|-----------------------|----------------|-------|
| Source Qualifier | `source()` macro | Defined in sources.yml |
| Expression TX | SELECT with CASE | Field transformations |
| Router TX | Multiple models with WHERE | Each route = separate model |
| Aggregator TX | GROUP BY in SELECT | SQL aggregation |
| Joiner TX | JOIN in SELECT | SQL joins |
| Target Definition | Materialization config | table/view/incremental |

### Key Differences

1. **Declarative vs. Procedural**: dbt uses SQL rather than GUI mappings
2. **Version Control**: All transformations are in SQL files in Git
3. **Testing**: Built-in testing framework
4. **Documentation**: Auto-generated docs from YAML and SQL
5. **Modularity**: Each transformation is a separate, testable model

## Troubleshooting

### Common Issues

**Issue**: "Relation does not exist"
```bash
# Check that sources are defined correctly
dbt run-operation test_source --args '{"source_name": "prov_ib", "table_name": "wi_ma_inbound_provider_file"}'
```

**Issue**: "Field not found in record"
```bash
# Verify field positions in parsed records
# Check that split_part indices match actual file structure
```

**Issue**: "Type conversion error"
```bash
# Use try_to_date() and try_to_number() for safety
# Check for invalid data in source
```

### Logging

Enable verbose logging:
```bash
dbt run --debug
dbt run --log-level debug
```

## Maintenance

### Daily Operations

1. Monitor file arrival at `/work/inform/SrcFiles/wi_medicaid`
2. Run inbound flow when new file arrives
3. Validate data quality checks
4. Run outbound flow to create export files
5. Verify control file record counts

### Monthly Tasks

1. Review and update data quality thresholds
2. Analyze performance metrics
3. Archive old staging data (90+ days)
4. Update documentation

## Performance Optimization

### Recommended Practices

1. **Partition large tables** by date/month
2. **Create indexes** on frequently joined columns
3. **Use incremental models** for large fact tables
4. **Tune thread count** based on warehouse capacity
5. **Monitor query performance** via dbt logs

### Sample Optimization

```sql
-- Add to model config for incremental processing
{{
    config(
        materialized='incremental',
        unique_key='provider_id',
        on_schema_change='append_new_columns'
    )
}}

-- Only process new records
{% if is_incremental() %}
where load_timestamp > (select max(load_timestamp) from {{ this }})
{% endif %}
```

## Support

### Resources

- **dbt Documentation**: https://docs.getdbt.com
- **dbt Discourse**: https://discourse.getdbt.com
- **dbt Slack**: https://www.getdbt.com/community/join-the-community

### Contact

- Data Team: data-team@example.com
- Slack: #data-pipeline-support

## License

[Your License Here]

## Changelog

### Version 1.0.0 (2026-01-29)
- Initial conversion from Informatica to dbt
- All 15 record types implemented
- Inbound and outbound flows complete
- Comprehensive testing and documentation

---

**Note**: This is a conversion of existing Informatica workflows. Field mappings and business logic should be validated against the original specifications and adjusted as needed for your specific requirements.
