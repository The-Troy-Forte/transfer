{{
    config(
        materialized='view',
        tags=['inbound', 'transformation', 'parsing']
    )
}}

/*
  Stage 2: Parse and route records by type
  
  This model splits the raw inbound records into separate CTEs based on
  the first 2 characters (record type) of the pipe-delimited string.
  
  In Informatica, this was: m_prov_ib_split_WI_medicaid_provider_incoming
  Using a Router transformation (RTR_type) to split by record type.
  
  DuckDB Version: Uses DuckDB's string_split and list functions
*/

with base as (
    select
        entire_record,
        load_timestamp,
        source_file_name,
        -- Extract record type (first 2 characters)
        substring(entire_record, 1, 2) as record_type,
        -- Split the entire record into an array
        string_split(entire_record, '|') as fields_array
    from {{ ref('stg_wi_ma_inbound_raw') }}
)

select
    record_type,
    entire_record,
    -- Extract individual fields from array (DuckDB uses 1-based indexing)
    fields_array[1] as field_01,
    fields_array[2] as field_02,
    fields_array[3] as field_03,
    fields_array[4] as field_04,
    fields_array[5] as field_05,
    fields_array[6] as field_06,
    fields_array[7] as field_07,
    fields_array[8] as field_08,
    fields_array[9] as field_09,
    fields_array[10] as field_10,
    fields_array[11] as field_11,
    fields_array[12] as field_12,
    fields_array[13] as field_13,
    fields_array[14] as field_14,
    fields_array[15] as field_15,
    fields_array[16] as field_16,
    fields_array[17] as field_17,
    fields_array[18] as field_18,
    fields_array[19] as field_19,
    fields_array[20] as field_20,
    -- Add more fields as needed based on max field count
    load_timestamp,
    source_file_name
from base
