{{
    config(
        materialized='table',
        tags=['inbound', 'type_01', 'provider']
    )
}}

/*
  Type 01: Provider Core Information
  
  Main provider record with identifying and status information.
  
  Field mapping (example - adjust based on actual file spec):
  - field_01: Record Type (01)
  - field_02: Provider ID
  - field_03: Provider Name
  - field_04: DBA Name
  - field_05: Provider Status
  - field_06: Effective Date
  - field_07: Termination Date
  - Additional fields as defined in source specification
*/

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as provider_name,
    trim(field_04) as dba_name,
    trim(field_05) as status,
    strptime(field_06, '%Y-%m-%d')::DATE as effective_date,
    strptime(field_07, '%Y-%m-%d')::DATE as termination_date,
    trim(field_08) as provider_type_code,
    trim(field_09) as medicaid_number,
    trim(field_10) as enrollment_status,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '01'
    and field_02 is not null
