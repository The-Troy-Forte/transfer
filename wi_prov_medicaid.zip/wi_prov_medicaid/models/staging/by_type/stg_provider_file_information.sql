{{
    config(
        materialized='table',
        tags=['inbound', 'type_00', 'file_info']
    )
}}

/*
  Type 00: Provider File Information
  
  File header record containing metadata about the source file.
  
  Field mapping:
  - field_01: Record Type (00)
  - field_02: File Name
  - field_03: File Date
  - field_04: Record Count
*/

select
    field_01 as record_type,
    field_02 as file_name,
    strptime(field_03, '%Y-%m-%d')::DATE as file_date,  -- DuckDB date conversion
    cast(field_04 as integer) as record_count,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '00'
