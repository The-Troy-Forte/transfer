{{
    config(
        materialized='table',
        tags=['inbound', 'type_02', 'address']
    )
}}

/*
  Type 02: Provider Address Information
  
  Address records for providers (mailing, physical, billing, etc.)
*/

select
    field_01 as record_type,
    trim(field_02) as provider_id,
    trim(field_03) as address_type,
    trim(field_04) as address_line_1,
    trim(field_05) as address_line_2,
    trim(field_06) as city,
    trim(field_07) as state,
    trim(field_08) as zip_code,
    trim(field_09) as county,
    trim(field_10) as country,
    strptime(field_11, '%Y-%m-%d')::DATE as effective_date,
    strptime(field_12, '%Y-%m-%d')::DATE as end_date,
    load_timestamp,
    source_file_name
from {{ ref('int_wi_ma_parsed_records') }}
where record_type = '02'
    and field_02 is not null
