{{
    config(
        materialized='table',
        tags=['inbound', 'staging', 'raw']
    )
}}

/*
  Stage 1: Load raw flat file from Wisconsin Medicaid
  
  This model loads the pipe-delimited file directly into DuckDB
  from C:\data\wi_medicaid\WI_PROV_FILE_EXTRACT.psv
  
  In Informatica, this was: m_ff_prov_ib_WI_medicaid_provider_incoming
  
  For DuckDB: We read the file directly using read_csv_auto function
*/

-- Option 1: Load from file directly (DuckDB native)
SELECT 
    column0 as entire_record,
    current_timestamp as load_timestamp,
    '{{ var("source_file_name") }}' as source_file_name
FROM read_csv_auto(
    '{{ var("source_file_path") }}\{{ var("source_file_name") }}',
    delim='|',
    header=false,
    columns={'column0': 'VARCHAR'},
    nullstr='',
    ignore_errors=false,
    max_line_size=10000
)
WHERE column0 IS NOT NULL
    AND trim(column0) != ''

-- Option 2: If you've already loaded to a table, uncomment below and comment above:
-- select
--     entire_record,
--     current_timestamp as load_timestamp,
--     '{{ var("source_file_name") }}' as source_file_name
-- from {{ source('prov_ib', 'wi_ma_inbound_provider_file') }}
-- where entire_record is not null
--     and trim(entire_record) != ''
