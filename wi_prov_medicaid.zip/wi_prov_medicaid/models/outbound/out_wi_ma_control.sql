{{
    config(
        materialized='table',
        schema='prov_ob',
        tags=['outbound', 'control']
    )
}}

/*
  Outbound Control File Model
  
  Generates control file metadata for the Wisconsin Medicaid outbound extract.
  
  This corresponds to the Informatica mapping:
  m_prov_eds_prov_ob_WI_MA_CONTROL
  
  Target: prov_ob.wi_ma_control_file
*/

with provider_counts as (
    select count(*) as provider_count
    from {{ ref('out_wi_ma_provider') }}
),

facility_counts as (
    select count(*) as facility_count
    from {{ ref('out_wi_ma_facility') }}
),

control_metadata as (
    select
        'WI_MEDICAID_PROVIDER_EXTRACT' as extract_name,
        current_date as extract_date,
        current_timestamp as extract_timestamp,
        pc.provider_count,
        fc.facility_count,
        (pc.provider_count + fc.facility_count) as total_record_count,
        'COMPLETED' as extract_status,
        {{ var("source_file_name", "WI_PROV_FILE_EXTRACT.psv") }} as source_file,
        'v1.0' as extract_version
    from provider_counts pc
    cross join facility_counts fc
)

select
    extract_name,
    extract_date,
    extract_timestamp,
    provider_count,
    facility_count,
    total_record_count,
    extract_status,
    source_file,
    extract_version
from control_metadata
