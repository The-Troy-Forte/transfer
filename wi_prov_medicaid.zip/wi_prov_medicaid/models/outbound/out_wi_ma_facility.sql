{{
    config(
        materialized='table',
        schema='prov_ob',
        tags=['outbound', 'facility']
    )
}}

/*
  Outbound Facility Model
  
  Transforms facility data from the EDS to the outbound schema for Wisconsin Medicaid.
  
  This corresponds to the Informatica mapping:
  m_prov_eds_prov_ob_WI_MA_FACILITY
  
  Source: prov_eds.wi_ma_facility_master
  Target: prov_ob.wi_ma_facility
*/

with facility_master as (
    select * from {{ source('prov_eds', 'wi_ma_facility_master') }}
),

facility_details as (
    select
        f.facility_id,
        f.provider_id,
        f.facility_name,
        f.facility_type,
        
        -- Add business transformations
        upper(trim(f.facility_name)) as facility_name_normalized,
        
        case
            when f.facility_type = 'HOSP' then 'Hospital'
            when f.facility_type = 'CLINIC' then 'Clinic'
            when f.facility_type = 'LTAC' then 'Long Term Acute Care'
            when f.facility_type = 'SNF' then 'Skilled Nursing Facility'
            else f.facility_type
        end as facility_type_description,
        
        current_timestamp as extract_timestamp
    from facility_master f
)

select
    facility_id,
    provider_id,
    facility_name,
    facility_name_normalized,
    facility_type,
    facility_type_description,
    extract_timestamp
from facility_details
where facility_id is not null
