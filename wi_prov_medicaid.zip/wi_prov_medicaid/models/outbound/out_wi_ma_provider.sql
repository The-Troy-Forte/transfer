{{
    config(
        materialized='table',
        schema='prov_ob',
        tags=['outbound', 'provider']
    )
}}

/*
  Outbound Provider Model
  
  Transforms provider data from the EDS (Enterprise Data Store) to the
  outbound schema for Wisconsin Medicaid.
  
  This corresponds to the Informatica mapping:
  m_prov_eds_prov_ob_WI_MA_PROVIDER
  
  Source: prov_eds.wi_ma_provider_master
  Target: prov_ob.wi_ma_provider
*/

with provider_master as (
    select * from {{ source('prov_eds', 'wi_ma_provider_master') }}
),

provider_details as (
    select
        p.provider_id,
        p.provider_name,
        p.npi,
        p.status,
        p.last_updated,
        -- Add transformations and business logic here
        case
            when p.status = 'A' then 'Active'
            when p.status = 'I' then 'Inactive'
            when p.status = 'T' then 'Terminated'
            else 'Unknown'
        end as status_description,
        
        -- Flag for current/active providers
        case
            when p.status = 'A' then 1
            else 0
        end as is_active_flag,
        
        current_timestamp as extract_timestamp
    from provider_master p
)

select
    provider_id,
    provider_name,
    npi,
    status,
    status_description,
    is_active_flag,
    last_updated as source_last_updated,
    extract_timestamp
from provider_details
where provider_id is not null
