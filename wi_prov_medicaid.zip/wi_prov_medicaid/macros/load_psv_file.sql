{% macro load_psv_file(file_path, delimiter='|') %}
/*
  Macro to load pipe-delimited (or other delimited) files into DuckDB
  
  Usage in a model:
    {{ load_psv_file('C:\\data\\wi_medicaid\\WI_PROV_FILE_EXTRACT.psv') }}
  
  Or with custom delimiter:
    {{ load_psv_file('C:\\data\\file.csv', ',') }}
*/

SELECT * FROM read_csv_auto(
    '{{ file_path }}',
    delim='{{ delimiter }}',
    header=false,
    columns={'entire_record': 'VARCHAR'},
    nullstr='',
    ignore_errors=true,
    max_line_size=10000
)

{% endmacro %}
