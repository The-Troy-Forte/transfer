# dbt Conversion – `mplt_src_cd`

Converted from Informatica PowerCenter Mapplet **`mplt_src_cd`**  
Repository: `Infa_ProdL_Repository / MEDICA_ODS_REUSABLE`  
Target database: **DuckDB**

---

## Mapplet logic at a glance

```
INPUT  ──►  EXP_INPUT  ──►  LKP_CD_DOMAIN_KEY  ──►  LKP_SRC_CD_KEY
                       └──►  EXP_PASSTHROUGH  ──►  OUTPUT (SRC_CD_KEY)
                                   │
                              (if no key found)
                                   └──►  ADD_SRC_CD_TBL  (stored proc)
```

| Infa component | dbt equivalent |
|---|---|
| `INPUT` | `stg_src_cd_input` (staging model) |
| `EXP_INPUT` | CTE `exp_input` in `int_mplt_src_cd` |
| `LKP_CD_DOMAIN_KEY` | `stg_cd_domain` + LEFT JOIN in `int_mplt_src_cd` |
| `LKP_SRC_CD_KEY` | `stg_src_cd_lkp` + LEFT JOIN in `int_mplt_src_cd` |
| `EXP_PASSTHROUGH` | CTE `exp_passthrough` in `int_mplt_src_cd` |
| `OUTPUT` | Final `SELECT` in `int_mplt_src_cd` |
| `ADD_SRC_CD_TBL` (SP) | Macro `insert_new_src_cd` (post-hook) |

---

## Expression translations

| Infa expression | DuckDB SQL |
|---|---|
| `IIF(ISNULL(x) OR x='-99','N/A',UPPER(x))` | `CASE WHEN x IS NULL OR x='-99' THEN 'N/A' ELSE UPPER(x) END` |
| `UPPER(RTRIM(LTRIM(x)))` | `UPPER(TRIM(x))` |
| `UPPER(x)` | `UPPER(x)` |
| `NVL(x,'N/A')` | `COALESCE(x,'N/A')` |

---

## Stored Procedure → Macro

The SP `ADD_SRC_CD_TBL` inserted a new row into `CIM.SRC_CD` when no
`SRC_CD_KEY` was resolved, returning the new surrogate key.

In dbt (read-only transform layer) DML inside a model is not permitted.  
The replacement approach:

1. `int_mplt_src_cd` flags unresolved rows with `is_new_src_cd = true`.
2. After the model runs, call the macro as a **post-hook** or **`run-operation`**:

```bash
dbt run-operation insert_new_src_cd --args '{"source_model": "int_mplt_src_cd"}'
```

Or wire it as a post-hook in `dbt_project.yml`:

```yaml
models:
  mplt_src_cd:
    intermediate:
      +post-hook: "{{ insert_new_src_cd() }}"
```

---

## Lookup policy – "Report Error" on multiple matches

Replicated as:
- `stg_src_cd_lkp` is unique on `(cd_domain_key, rec_src_cd, src_cd)` by design.
- The generic test `no_duplicate_lookup_match` enforces this.
- If duplicates exist, the LEFT JOIN returns multiple rows (surfaced by the test).

---

## File layout

```
dbt_mplt_src_cd/
├── dbt_project.yml
├── profiles.yml
├── models/
│   ├── schema.yml
│   ├── staging/
│   │   ├── stg_src_cd_input.sql      # INPUT transformation
│   │   ├── stg_cd_domain.sql         # LKP_CD_DOMAIN_KEY source
│   │   └── stg_src_cd_lkp.sql        # LKP_SRC_CD_KEY source
│   └── intermediate/
│       └── int_mplt_src_cd.sql       # full mapplet logic
├── macros/
│   └── insert_new_src_cd.sql         # ADD_SRC_CD_TBL SP equivalent
└── tests/
    └── test_no_duplicate_lookup_match.sql
```
