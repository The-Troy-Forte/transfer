-- =============================================================================
-- Macro : insert_new_src_cd
-- Origin: Stored Procedure  ADD_SRC_CD_TBL  in Informatica mapplet mplt_src_cd
--
-- Original SP signature:
--   ADD_SRC_CD_TBL(
--       IN_TABLE_NM      VARCHAR,
--       IN_COLUMN_NM     VARCHAR,
--       IN_SRC_CD        VARCHAR,
--       IN_SRC_CD_DESC   VARCHAR,
--       IN_REC_SRC_CD    VARCHAR,
--       IN_DOMAIN_CD_KEY DOUBLE,
--       OUT SRC_CD_KEY   DOUBLE        -- newly generated surrogate key
--   )
--
-- Purpose:
--   Insert rows into CIM.SRC_CD that were not found by the LKP_SRC_CD_KEY
--   lookup (is_new_src_cd = true).  The new surrogate key is derived using
--   DuckDB's sequence or a MAX()+1 pattern.
--
-- Usage in dbt (post-hook or run-operation):
--   {{ insert_new_src_cd(source_model='int_mplt_src_cd') }}
-- =============================================================================

{% macro insert_new_src_cd(source_model='int_mplt_src_cd') %}

{% set insert_sql %}

insert into {{ source('cim', 'src_cd') }} (
    src_cd_key,
    cd_domain_key,
    src_cd,
    src_cd_desc,
    rec_src_cd,
    table_nm,
    column_nm,
    curr_indc
)

with next_key as (
    -- generate surrogate keys for new rows using row_number + current max
    select
        coalesce(max(src_cd_key), 0) as max_key
    from {{ source('cim', 'src_cd') }}
),

new_rows as (
    select
        table_nm,
        column_nm,
        src_cd,
        src_cd_desc,
        rec_src_cd,
        cd_domain_key
    from {{ ref(source_model) }}
    where is_new_src_cd = true
)

select
    nk.max_key + row_number() over ()   as src_cd_key,   -- new surrogate key
    nr.cd_domain_key,
    nr.src_cd,
    nr.src_cd_desc,
    nr.rec_src_cd,
    nr.table_nm,
    nr.column_nm,
    1                                   as curr_indc      -- mark as current
from new_rows nr
cross join next_key nk

{% endset %}

{% do run_query(insert_sql) %}
{% do log("insert_new_src_cd: inserted new SRC_CD rows for unmapped codes.", info=true) %}

{% endmacro %}
