-- =============================================================================
-- Model : stg_cd_domain.sql
-- Layer : Staging
-- Origin: Informatica Mapplet  mplt_src_cd  →  LKP_CD_DOMAIN_KEY lookup
--
-- Lookup SQL override (original):
--   SELECT CD_DOMAIN_KEY, UPPER(CD_DOMAIN_NME) AS CD_DOMAIN_NME
--   FROM CIM.CD_DOMAIN
-- =============================================================================

with source as (

    select *
    from {{ source('cim', 'cd_domain') }}

),

transformed as (

    select
        cast(cd_domain_key as double)             as cd_domain_key,
        upper(cd_domain_nme)                      as cd_domain_nme   -- normalised for join

    from source

)

select * from transformed
