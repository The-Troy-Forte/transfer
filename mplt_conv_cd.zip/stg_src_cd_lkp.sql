-- =============================================================================
-- Model : stg_src_cd_lkp.sql
-- Layer : Staging
-- Origin: Informatica Mapplet  mplt_src_cd  →  LKP_SRC_CD_KEY lookup
--
-- Lookup SQL override (original):
--   SELECT SRC_CD_KEY,
--          CD_DOMAIN_KEY,
--          REC_SRC_CD,
--          UPPER(NVL(SRC_CD, 'N/A')) AS SRC_CD
--   FROM CIM.SRC_CD
--   WHERE CURR_INDC = 1
-- =============================================================================

with source as (

    select *
    from {{ source('cim', 'src_cd') }}
    where curr_indc = 1                            -- active records only

),

transformed as (

    select
        cast(src_cd_key    as double)              as src_cd_key,
        cast(cd_domain_key as double)              as cd_domain_key,
        rec_src_cd,
        upper(coalesce(src_cd, 'N/A'))             as src_cd   -- NVL + UPPER

    from source

)

select * from transformed
