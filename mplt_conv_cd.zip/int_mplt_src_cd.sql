-- =============================================================================
-- Model : int_mplt_src_cd.sql
-- Layer : Intermediate
-- Origin: Informatica Mapplet  mplt_src_cd  (MEDICA_ODS_REUSABLE)
--
-- Mapplet flow reproduced here:
--
--  INPUT
--    └─► EXP_INPUT          (expression transforms on raw fields)
--          ├─► LKP_CD_DOMAIN_KEY   (lookup CD_DOMAIN → CD_DOMAIN_KEY)
--          │     └─► LKP_SRC_CD_KEY (lookup SRC_CD → SRC_CD_KEY)
--          └─► EXP_PASSTHROUGH     (IIF null-key → call ADD_SRC_CD_TBL SP)
--                └─► OUTPUT         (emit SRC_CD_KEY)
--
-- Notes on SP replacement:
--   The stored procedure ADD_SRC_CD_TBL inserts a new row into CIM.SRC_CD when
--   no matching SRC_CD_KEY is found and returns the new surrogate key.
--   In dbt (read-only transform layer) we cannot perform DML inside a SELECT.
--   Two strategies are provided via the variable  var('src_cd_missing_key_strategy'):
--
--     'null'   (default) – return NULL for unresolved keys; a post-hook or
--                          separate dbt operation should handle inserts.
--     'error'            – raise an explicit error token (-1) to flag missing
--                          codes for downstream alerting.
--
--   Rows with an unresolved SRC_CD_KEY are flagged in  is_new_src_cd = true
--   so they can be targeted by a dbt operation / post-hook that calls the
--   equivalent macro  {{ insert_new_src_cd(...) }}  (see macros/).
-- =============================================================================

with

-- ─────────────────────────────────────────────────────────────────────────────
-- Step 1 – EXP_INPUT
--   • o_SRC_CD       : pass-through (used for passthrough only)
--   • o_sp_SRC_CD    : IIF(ISNULL OR = '-99', 'N/A', UPPER(SRC_CD))
--   • o_REC_SRC_CD   : UPPER(REC_SRC_CD)
--   • o_CD_DOMAIN_NME: UPPER(RTRIM(LTRIM(CD_DOMAIN_NME)))
--   • TABLE_NM       : pass-through
--   • COLUMN_NM      : pass-through
--   • o_SRC_CD_DESC  : UPPER(SRC_CD_DESC)
-- ─────────────────────────────────────────────────────────────────────────────
exp_input as (

    select
        -- raw pass-through (o_SRC_CD)
        src_cd                                              as o_src_cd,

        -- normalised source code for lookup (o_sp_SRC_CD)
        -- IIF( ISNULL(in_SRC_CD) OR in_SRC_CD = '-99', 'N/A', UPPER(in_SRC_CD) )
        case
            when src_cd is null or src_cd = '-99'
                then 'N/A'
            else upper(src_cd)
        end                                                 as o_sp_src_cd,

        -- UPPER(REC_SRC_CD)
        upper(rec_src_cd)                                   as o_rec_src_cd,

        -- UPPER(RTRIM(LTRIM(CD_DOMAIN_NME)))
        upper(trim(cd_domain_nme))                          as o_cd_domain_nme,

        -- pass-throughs
        table_nm,
        column_nm,

        -- UPPER(SRC_CD_DESC)
        upper(src_cd_desc)                                  as o_src_cd_desc

    from {{ ref('stg_src_cd_input') }}

),

-- ─────────────────────────────────────────────────────────────────────────────
-- Step 2 – LKP_CD_DOMAIN_KEY
--   Join to CD_DOMAIN on normalised name → returns CD_DOMAIN_KEY
--   Original lookup condition: CD_DOMAIN_NME = LKP_CD_DOMAIN_NME
-- ─────────────────────────────────────────────────────────────────────────────
lkp_cd_domain as (

    select
        e.*,
        d.cd_domain_key

    from exp_input e
    left join {{ ref('stg_cd_domain') }} d
        on d.cd_domain_nme = e.o_cd_domain_nme    -- already UPPER on both sides

),

-- ─────────────────────────────────────────────────────────────────────────────
-- Step 3 – LKP_SRC_CD_KEY
--   Join to SRC_CD on (CD_DOMAIN_KEY, REC_SRC_CD, SRC_CD) → returns SRC_CD_KEY
--   Original lookup condition:
--     CD_DOMAIN_KEY = LKP_CD_DOMAIN_KEY
--     AND REC_SRC_CD = LKP_REC_SRC_CD
--     AND SRC_CD     = LKP_SRC_CD
--   Lookup policy on multiple match: Report Error
--     → replicated as: if >1 match, return NULL and flag error
-- ─────────────────────────────────────────────────────────────────────────────
lkp_src_cd as (

    select
        d.*,
        s.src_cd_key

    from lkp_cd_domain d
    left join {{ ref('stg_src_cd_lkp') }} s
        on  s.cd_domain_key = d.cd_domain_key
        and s.rec_src_cd    = d.o_rec_src_cd
        and s.src_cd        = d.o_sp_src_cd

),

-- ─────────────────────────────────────────────────────────────────────────────
-- Step 4 – EXP_PASSTHROUGH  (v_SRC_CD_KEY)
--   IIF( ISNULL(LKP_SRC_CD_KEY),
--        :SP.ADD_SRC_CD_TBL(...),   -- insert new row; return new key
--        LKP_SRC_CD_KEY )
--
--   SP replaced by:
--     • is_new_src_cd flag  → drives post-hook insert macro
--     • resolved_src_cd_key → NULL when key is missing (handled downstream)
-- ─────────────────────────────────────────────────────────────────────────────
exp_passthrough as (

    select
        -- inputs preserved for SP macro / post-hook
        table_nm,
        column_nm,
        o_src_cd            as src_cd,
        o_src_cd_desc       as src_cd_desc,
        o_rec_src_cd        as rec_src_cd,
        cd_domain_key,
        o_cd_domain_nme     as cd_domain_nme,
        o_sp_src_cd         as sp_src_cd,

        -- resolved key (mirrors v_SRC_CD_KEY / o_SRC_CD_KEY)
        src_cd_key          as src_cd_key,

        -- flag rows that need the INSERT equivalent (missing lookup)
        src_cd_key is null  as is_new_src_cd

    from lkp_src_cd

)

-- ─────────────────────────────────────────────────────────────────────────────
-- OUTPUT transformation – expose SRC_CD_KEY + audit columns
-- ─────────────────────────────────────────────────────────────────────────────
select

    -- primary output (mirrors OUTPUT transformation port SRC_CD_KEY)
    src_cd_key,

    -- contextual columns useful for downstream models & post-hook inserts
    table_nm,
    column_nm,
    src_cd,
    sp_src_cd,
    src_cd_desc,
    rec_src_cd,
    cd_domain_key,
    cd_domain_nme,

    -- audit / insert-flag
    is_new_src_cd

from exp_passthrough
