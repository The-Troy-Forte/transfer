-- =============================================================================
-- Model : stg_src_cd_input.sql
-- Layer : Staging
-- Origin: Informatica Mapplet  mplt_src_cd  →  INPUT transformation
--
-- Purpose:
--   Provides a clean, typed pass-through of the raw source columns that feed
--   the mapplet.  Swap {{ source(...) }} ref for your actual upstream table.
-- =============================================================================

with source as (

    select *
    from {{ source('cim_raw', 'src_cd_input') }}   -- replace with your source table

),

staged as (

    select
        cast(src_cd        as varchar)  as src_cd,
        cast(rec_src_cd    as varchar)  as rec_src_cd,
        cast(cd_domain_nme as varchar)  as cd_domain_nme,
        cast(table_nm      as varchar)  as table_nm,
        cast(column_nm     as varchar)  as column_nm,
        cast(src_cd_desc   as varchar)  as src_cd_desc

    from source

)

select * from staged
